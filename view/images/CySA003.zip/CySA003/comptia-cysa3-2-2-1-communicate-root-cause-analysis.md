## Communicate Root Cause Analysis

At the end of this episode, I will be able to:    

1. Identify the importance of communicating post-incident response processes.    

Learner Objective: *Identify the importance of communicating post-incident response processes*    

Description: In this episode, the learner will identify the importance post-incident response processes such as root cause analysis and lessons learned.

--------  

* Root Cause Analysis \(RCA\) - investigation to discover the underlying cause\(s\) for security incidents
 	+ Identify vulnerabilities and or contributing factors
	+ Clear and consise breakdown of the underlying circumstances
		- Timeline of events
	+ Discovery circumstances can effect other systems
		- Example: missing security on the effected system as well as other directly effected systems
	+ Deploy strategic controls/countermeasures
	+ Reduce or limit the impact 
	+ Avoid reoccurence
* RCA Report - may be necessary for compliance reporting
	+ Date and time of the incident occurence
	+ What event happened
	+ How was the incident discovered
	+ Who reported the incident
* Lessons Learned
	+ Incident Response Team \(IRT\) and everyone involved in the incident response process should be included
	+ Formal session\(s\)
	+ What went right, what went wrong, where can we improve?
	+ Identify roadblocks or barriers to remediation and recovery
	+ Can identify changes that need to be made to the incident response plan \(IRP\)
	+ Identify and document new Indicatiors of Compromise \(IOC\)
-----------


Additional Resources:
	+ If applicable
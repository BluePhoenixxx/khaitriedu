Filename: cysa-1b-4-3-1-integrating-tools-and-technology-into-security-operations.md
Domain: Efficiency and Process Improvement in Security Operations
Episode: Integrating Tools and Technology Into Security Operations
=========================================================================

Integrating Tools and Technology Into Security Operations
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Application programming interface (API)
  - https://developers.virustotal.com/reference/overview
+ Webhooks
+ Plugins
  - https://addons.mozilla.org/en-US/firefox/addon/vt4browsers/
+ Single Pane of Glass

## Containment, Eradication, and Recovery
At the end of this episode, I will be able to:    

1. Given a scenario, perform incident response activities, including proper containment, eradication, and recovery. 

Learner Objective: *Discuss the typical steps of containment, eradication, and recovery during incident response.*    

Description: In this episode, you will learn about the incident response phases of containment, eradication, and recovery. These are key steps in most typical incident response environments. 

--------  

* Containment, Eradication, and Recovery
	+ Containment - reduce or eliminate the spread of the incident; includes preserving evidence
	+ Eradication - return all systems to a known good state; rebuild systems
	+ Recovery -  identify the relevant attack vectors and implement countermeasures 
	 
-----------

Additional Resources:

*The 6 Phases of a Cyber Incident Response Plan*
https://www.grcilaw.com/blog/the-6-phases-of-a-cyber-incident-response-plan
Filename: cysa-1b-2-4-1-dns-and-ip-reputation-tools.md
Domain: Tools and Techniques for Determining Malicious Activity
Episode: DNS and IP Reputation Tools
=========================================================================

DNS and IP Reputation Tools
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Define DNS and IP reputation
  - DNS Reputation
    + Focused on Domain Names associated with IPs
    + Determines if a domain name has been associated with suspicious or
      malicious behavior
      - Spam 
      - Phishing
      - Malware
  - IP Reputation
    + Determintes if an IP address has been associated with suspicious or 
      malicious behavior
      - Spam
      - Phishing
      - Malware

+ How are DNS/IP Reputations used by security professionals?
  - Can be used to block access to websites or other online resources
    associated with the domain.
  - Often used by web filtering and security services to help protect 
    users from accessing potentially harmful websites.

+ WHOIS
  - Can't perform reputation lookup
    + Can be used to get the NameServer info for a Domain
      - Then you can check the reputation for the NameServers
	+ https://talosintelligence.com/reputation_center
+ AbuseIPDB
  - https://abuseipdb.com

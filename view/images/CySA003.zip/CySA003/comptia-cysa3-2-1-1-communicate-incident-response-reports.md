## Communicate Incident Response Reports

At the end of this episode, I will be able to:    

1.  Communicate the importance of incident response finding to appropriate stakeholders.    

Learner Objective: *Communicate the importance of incident response finding to appropriate stakeholders.*    

Description: In this episode, the learner will identify common stakeholder in incident response reporting, including the components of the incident response report.

--------  

* Communications \(1\)
	+ Stakeholders
		- IT security team - technical aspects of the incident
			- Incident declaration - who is authoritative?
				- Communicate the process
				- Name\(s\)
				- Position\(s\)
			- Who handles the response?
				- Names
				- Positions
				- Contact information
			- Incident escalation?
				- Communicate the process
				- Name\(s\)
				- Position\(s\)
		- Executives - make key decisions \(CTO, CISO\)
			- Higher level view of the incident
			- Do not care about the minutiae
			- Summarization of key events
		- Legal - \(local, city, state and federal\)
			- Working with legal counsel
			- Ensure the response strategy is in compliance with regulations or laws, including obligations through contracts \(MOU,SLA\)
			- For example: Customer data breach, or payment card information
		- Public relations
			* Support services 
			* Customer services \(SLAs not met, data breach, outages\)
			* Public Media
		- Regulatory authority reporting - \(local, city, state and federal\)
			- Examples: potential HIPPA violation, GDPR voliation
		- Law enforcement - \(local, city, state and federal\)
			- Civil or criminal liabilities
	* Incident response reporting \(2\)
		+ Executive summary - high-level summarization of key findings
		+ 5 W's
			- Who - Threat actor
			- What - Type of occurence, threat vector/method
			- When - Time of occurence
			- Where - What system, process, application or physical location the incident occured
			- Why - Identified vulnerability \(or vulnerabilities\)
		+ Recommendations - strategic advice on controls to implement or deploy \(countermeasures\)
		+ Timeline - a complete record of the event from detection to remediation
		+ Impact - details the effect of the incident to the organization
		+ Scope - details the range of the effect to the organization
		+ Evidence - preservation of all documentation for examination at a later time \(think of chain of custody, timestamps....)

-----------

Additional Resources:
	+ If applicable
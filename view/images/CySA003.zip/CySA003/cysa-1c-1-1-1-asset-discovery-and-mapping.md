Filename: 1-1-1-asset-discovery-and-mapping.md
Domain: Implement Vulnerability Scanning Methods and Concepts
Episode: Asset Discovery and Mapping
=========================================================================

Asset Discovery and Mapping
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


 + Map Scans
  - Ping Sweep
  - Nmap/Zenmap
 + Device Fingerprinting
  - Type
    + Server
    + Desktop
    + Mobile
    + IoT
    + Networking
  - Operating System
  - Ports/Services
 + Angry IP Scanner
 + Maltego

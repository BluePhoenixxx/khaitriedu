Filename: cysa-1b-1-3-1-malicious-application-activity.md
Domain: Analyze Indicators of Potentially Malicious Activity
Episode: Malicious Application Activity
=========================================================================

Malicious Application Activity
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------



+ Anomalous activity
+ Introduction of new accounts
+ Unexpected output
+ Unexpected outbound communication
+ Service interruption
+ Application logs

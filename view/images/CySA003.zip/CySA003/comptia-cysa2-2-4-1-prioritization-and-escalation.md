## Prioritization and Escalation
At the end of this episode, I will be able to:    

1. Understand the concepts of prioritization and escalation 

Learner Objective: *Explain the concepts of prioritization and escalation as they refer to cybersecurity incident response*    

Description: In this episode, you will learn about the important concepts of prioritization and escalation in the cybersecurity IT space.  

--------  

* Prioritization and Escalation 
	+ Prioritization - we can use the NIST SP 800-61 for guidance
		- Evaluate based on:
			- Functional impact of the incident - NONE-LOW-MEDIUM-HIGH
			- Information impact of the incident - NONE-PRIVACY BREACH-PROPRIETARY BREACH-INTEGRITY LOSS
			- Recoverability from the incident - REGULAR-SUPPLEMENTED-EXTENDED-NOT RECOVERABLE
	+ Escalation
		- Incident response policy should identify: 
			- Potential escalation points in the process
			- Procedures for escalation
			- On-call information 
			- Escalation procedure should detail everything including acceptable and expected wait times 

	 
-----------

Additional Resources:

*NIST SP 800-61*
https://learn.saylor.org/mod/book/view.php?id=29706&chapterid=5347
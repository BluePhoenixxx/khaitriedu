## Preparation Phase
At the end of this episode, I will be able to:    

1. Explain the preparation and post-incident activity phases of the incident management lifecycle.

Learner Objective: *Explain the preparation of the preparation phase for the incident response plan.*    

Description: In this episode, you will learn about the important preparation phase for the incident response plan. This includes a discussion of the tools playbooks, and training that might take place in this phase.  

--------  

* Preparation Phase
	+ Incident response plan
	+ Tools
	+ Playbooks
	+ Tabletop
	+ Training 
	+ BC/DR
	 
-----------

Additional Resources:

*Cyber Security Tabletop Excercises*
https://www.cm-alliance.com/cybersecurity-blog/cyber-attack-tabletop-exercises-everything-you-need-to-know
## Attack Surface Management
At the end of this episode, I will be able to:    

1. Explain concepts related to attack surface management in cybersecurity environments. 

Learner Objective: *Explain the concept of attack surface management as it relates to cybersecurity*    

Description: In this episode, you will learn about an important cyber security concept called attack surface management. 

--------  

* Attack Surface Management
	+ Edge discovery
	+ Passive discovery
	+ Security controls testing
	+ Penetration testing and adversary emulation
	+ Bug bounty - payments for finding bugs
	+ Attack surface reduction 
	 
-----------

Additional Resources:

*Attack Surface*
https://en.wikipedia.org/wiki/Attack_surface
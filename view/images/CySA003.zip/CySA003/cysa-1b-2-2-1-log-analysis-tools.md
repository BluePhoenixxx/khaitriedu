Filename: cysa-1b-2-2-1-log-analysis-tools.md
Domain: Tools and Techniques for Determining Malicious Activity
Episode: Log Analysis Tools
=========================================================================

Log Analysis Tools
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Security Information and Event Management (SIEM)
  - Log aggregation system
    + Alerts generated based on conditions
+ Securiy Orchestration, Automation, and Response (SOAR)
  - Integrates with security tools and technologies
    + CTI
    + SIEM
    + EDR
    + Vulnerability Mangement
    + More
  - Helps teams to...
    + Detect, Prioritize, and Respond to Threats

Filename: 3-1-1-cvss.md
Domain: Implement Vulnerability Scanning Methods and Concepts
Episode: CVSS
=========================================================================

CVSS
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------

+ https://www.first.org/cvss/v3.1/specification-document
+ Base Metric Group
  - Exploitability Metrics
    + (AV) Attack Vectors
      - (N) Network
      - (A) Adjacent
      - (L) Local
      - (P) Physical
    + (AC) Attack Complexity
      - (L) Low
      - (H) High
    + (PR) Privileges Required
      - (N) None
      - (L) Low
      - (H) High
    + (UI) User Interaction
      - (N) None
      - (R) Required
    + (S) Scope
      - (U) Unchanged
      - (C) Changed
  - Impact Metrics
    + (C) Confidentiality
      - (H) High
      - (L) Low
      - (N) None
    + (I) Integrity
      - (H) High 
      - (L) Low
      - (N) None
    + (A) Availability
      - (H) High 
      - (L) Low
      - (N) None

+ Qaulitative Severity Rating Scale
  - Critical
    + 9.0 - 10.0
  - High
    + 7.0 - 8.9
  - Medium
    + 4.0 - 6.9
  - Low
    + 0.1 - 3.9
  - None
    + 0.0

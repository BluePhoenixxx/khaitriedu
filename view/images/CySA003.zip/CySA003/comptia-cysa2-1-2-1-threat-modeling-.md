## Threat Modeling
At the end of this episode, I will be able to:    

1. Describe the benefits of threat modeling and how many companies choose to use this valuable technique 

Learner Objective: *Describe threat modeling*    

Description: In this episode, you will first understand the process of threat modeling and what it entails and why we are performing it. We will then discuss specific frameworks for threat modeling. 

--------  

* Threat Modeling
	+ This is a procedure for testing the security of an organization against attacks
	+ You should perform threat modeling early and often
	+ The security team will be heavily involved, and will also learn the architecture must better as a result of the exercise
	+ We often examine factors such as:
		- Adversary capability 
		- Total Attack Surface 
		- Attack vector 
		- Impact
		- Likelihood 
	+ Sample Frameworks
		- STRIDE
		- PASTA
	 
-----------

Additional Resources:

*Threat Modeling*
https://owasp.org/www-community/Threat_Modeling
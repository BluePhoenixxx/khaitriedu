## Post-Incident Activity
At the end of this episode, I will be able to:    

1. Explain the post-incident activity phase of a typical incident response plan.

Learner Objective: *Explain the preparation and post-incident activity phases of the incident management lifecycle*    

Description: In this episode, you will learn about the important post-incident activities that you should consider when running an incident response plan. 

--------  

* Post-Incident Activity 
	+ This phase will often include forensic analysis 
	+ Forensic analysis - also called digital forensics; legal compliance guidelines; may involve data recovery
	+ Root cause analysis - defined by the NIST; a principle-based, system approach for the identification of underlying causes associated with a particular set of risks 
	+ Lessons learned - often in the form of a report; typical format - issue; discussion; recommendation 
	 
-----------

Additional Resources:

*NIST - Computer Security Incident Handling Guide*
https://nvlpubs.nist.gov/nistpubs/specialpublications/nist.sp.800-61r2.pdf
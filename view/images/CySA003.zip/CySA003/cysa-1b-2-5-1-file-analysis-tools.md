Filename: cysa-1b-2-5-1-file-analysis-tools.md
Domain: Tools and Techniques for Determining Malicious Activity
Episode: File Analysis Tools
=========================================================================

File Analysis Tools
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Strings
+ Hashing
+ VirusTotal

Filename: cysa-1b-4-2-1-streamlining-operations.md
Domain: Efficiency and Process Improvement in Security Operations
Episode: Streamlining Operations
=========================================================================

Streamlining Operations
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Automation and orchestration
  - Security orchestration, automation, and response (SOAR)
+ Orchestrating threat intelligence data
  - Data enrichment
    + Improves SIEM capabilities by integrating contextual information
      - Group Membership, Geolocation, Social Media, Treat Intel, etc
        + Better detections through Threat Intelligence
        + Better asset risk categorization
        + Better prioritization of alerts
  - Threat feed combination
+ Minimize human engagement
  - Allows humans to...
    + Focus more on more difficult tasks
    + Reduces human-error
    + Increases effciency

Filename: cysa-1b-1-4-1-other-malicious-activity.md
Domain: Analyze Indicators of Potentially Malicious Activity
Episode: Other Malicious Activity
=========================================================================

Other Malicious Activity
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Social engineering attacks
+ Obfuscated links

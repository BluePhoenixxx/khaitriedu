## Secure Coding Best Practices
At the end of this episode, I will be able to:    

1. Explain secure coding best practices 

Learner Objective: *Explain some of the best practices used in secure coding environments.*    

Description: In this episode, you will learn to help developers implement secure coding best practices.  

--------  

* Secure Coding Best Practices 
	+ Input validation
	+ Output encoding 
	+ Session management
	+ Authentication 
	+ Data protection
	+ Parameterized queries 
	 
-----------

Additional Resources:

*Secure Coding Best Practices*
https://kirkpatrickprice.com/blog/secure-coding-best-practices/
Filename: 1-2-1-common-operating-system-concepts.md
Domain: System and Network Architecture Concepts in Security Operations
Episode: Common Operating System Concepts
=========================================================================

Common Operating System Concepts
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Windows Registry
  - HKEY_CLASSES_ROOT
    + Config info about the app used to open files
  - HKEY_CURRENT_USER
    + Profile of currently logged-on user
  - HKEY_LOCAL_MACHINE
    + Config info about computer hardware and software
  - HKEY_USERS
    + All user profile config
  - HKEY_CURRENT_CONFIG
    + System startup hardware profile
+ System Hardening
+ File Structure
  - Configuration File Locations
    + `C:\Windows\System32`
    + `/etc`
    + `/var`
    + `/root`
    + `/`
+ System Processes
  - Task Manager
  - Procmon
  - top/htop
+ Hardware Architecture
  - x86
  - amd64 (aka x86_64, x64)

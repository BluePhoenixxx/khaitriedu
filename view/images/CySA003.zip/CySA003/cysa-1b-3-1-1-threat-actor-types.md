Filename: cysa-1b-3-1-1-threat-actor-types.md
Domain: Threat Intelligence and Threat Hunting Concepts
Episode: Threat Actor Types
=========================================================================

Threat Actor Types
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Script Kiddie
+ Insider Threats
  - Intentional
  - Unintentional
+ Hacktivists
+ Organized Crime
+ Nation-State
+ Advanced Persistent Threat(APT)
+ Supply-Chain

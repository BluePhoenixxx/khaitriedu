## Policies, Governance, and SLOs
At the end of this episode, I will be able to:    

1.  Explain the meaning of policies, governance, and SLOs

Learner Objective: *Policies, governance, and SLOs*    

Description: In this episode, you will learn about the importance and meaning of policies, governance, and service-level objectives (SLOs). You will be provided with valuable examples of each. 

--------  

* Policies, Governance, and SLOs
	+ Policies -  organizational rules of conduct 
	+ Governance - refers to both corporate governance and external governance (such as a government controlling an organization)
	+ SLOs - service-level objectives; these typically help build the SLA (service-level agreement)
	 
-----------

Additional Resources:

*What are SLOs*
https://www.dynatrace.com/news/blog/what-are-slos/
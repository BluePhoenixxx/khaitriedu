Filename: 1-6-1-protecting-sensitive-data.md
Domain: System and Network Architecture Concepts in Security Operations
Episode: Protecting Sensitive Data
=========================================================================

Protecting Sensitive Data
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------

+ Data loss prevention (DLP)
+ Personally identifiable information (PII)
+ Cardholder data (CHD)

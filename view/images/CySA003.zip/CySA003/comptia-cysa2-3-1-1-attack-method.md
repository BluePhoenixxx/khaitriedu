## Attack Methodology Frameworks
At the end of this episode, I will be able to:    

1. Explain concepts related to attack methodology frameworks including the cyber kill chain, OWASP testing guide, and many more

Learner Objective: *Explain concepts related to attack methodology frameworks*    

Description: In this episode, you will be able to describe various attack methodology frameworks used in modern cybersecurity environments.

--------  

* Attack Methodology Frameworks
	+ Cyber kill chain
	+ Diamond model of intrusion analysis
	+ MITRE ATT&CK
	+ Open Source Security Testing Methodology Manual (OSS TMM)
	+ OWASP Testing Guide 
	 
-----------

Additional Resources:

*Attack Methodology Frameworks*
https://fndn.fortinet.net/accelerate/attack_kill_chain/index.html
Filename: cysa-1b-3-4-1-cti-sources.md
Domain: Threat Intelligence and Threat Hunting Concepts
Episode: CTI Sources
=========================================================================

CTI Sources
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Open Source
  - Social Media
  - Blogs/Forums
    + https://symantec-enterprise-blogs.security.com/blogs/threat-intelligence
    + https://www.mandiant.com/resources/blog
    + https://www.reddit.com/r/threatintel
  - Government Bulletins
    + https://www.cisa.gov/news-events/cybersecurity-advisories
  - CERT and CSIRT
    + https://sei.cmu.edu/about/divisions/cert/index.cfm
    + https://www.first.org
  - Deep/Dark Web
    + The Hidden Wiki

+ Closed Source
  - Paid Feeds
    + CrowdStrike Falcon Intelligence
    + Mandiant Threat Intelligence
    + Anomali ThreatStream
  - Information Sharing Organizations
  - Internal Sources
    + SIEM
    + Honeypots

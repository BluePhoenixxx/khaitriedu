## System Maintenance Procedures
At the end of this episode, I will be able to:    

1. Explain the various system maintenance procedures that are common in organizations today for IT operations. 

Learner Objective: *Explain the concepts of configuration management, patching, maintenance windows, and exceptions*    

Description: In this episode, you will learn to explain the various concepts around system maintenance procedures. This includes a discussion of patching, maintenance windows, patching systems, and exceptions. 
--------  

* System Maintenance Procesdures 
	+ Patching
		- Testing
		- Implementation
		- Rollback
		- Validation 
	+ Configuration Management 
	+ Maintenance Windows 
	+ Exceptions 
	 
-----------

Additional Resources:

*Configuration Management*
https://en.wikipedia.org/wiki/Configuration_management
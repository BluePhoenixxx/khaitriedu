## Detection and Analysis
At the end of this episode, I will be able to:    

1. Given a scenario, perform incident response activities surrounding the detection and analysis phase

Learner Objective: *Discuss the typical detection and analysis activities that take place during incident response*    

Description: In this episode, you will learn about the detection and analysis phase of a typical incident response. This episode provides specific guidance on what type of activities in your IT environment are often indicators of compromise. 

--------  

* Detection and Analysis
	+ Indicators of compromise
	+ Network-Related Indicators
		- Bandwidth
		- Beaconing
		- Irregular P2P communication
		- Rogue devices
		- Common protocols over nonstandard ports
	+ Host-Related Indicators
		- Capacity consumption
		- Unauthorized software
		- Whitelisting
		- Malicious processes
		- Memory contents
		- Unauthorized changes
		- File system
		- Unauthorized privileges 
		- Data exfiltration
		- Registry changes
		- Unauthorized scheduled tasks
	+ Application-Related Indicators
		- Anomalous activity
		- New accounts
		- Unexpected output
		- Unexpected outbound communication
		- Service interruption
		- Memory overflows
		- Application logs
	+ Evidence acquisitions 
		- Chain of custody  
		- Validating data integrity 
		- Preservation 
		- Legal hold 
	+ Data and log analysis 

	 
-----------

Additional Resources:

*Indicators of Compromise*
https://www.fortinet.com/resources/cyberglossary/indicators-of-compromise

*Legal Hold*
https://www.techopedia.com/definition/14216/legal-hold
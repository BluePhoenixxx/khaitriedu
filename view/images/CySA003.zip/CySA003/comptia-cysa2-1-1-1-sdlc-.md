## SDLC
At the end of this episode, I will be able to:    

1. Describe the SDLC and how it impacts cybersecurity specialists

Learner Objective: *Secure the Software Development Lifecycle*    

Description: In this episode, you will learn about the critical Software Development Lifecycle (SDLC) that companies use in order to assist with software development. It is important that cyber security analysts be familiar with this process since they are often required to provide guidance for security concerns during the various phases of the SDLC. 

--------  

* SDLC
	+There are many approaches to the SDLC
	+It typically starts with the identification of an unmet need and they typically end with a retirement of the software 
	+There are many tasks in this process and many places where cybersecurity experts are needed
	+Typical tasks include:	
		- Identify the organizational needs
		- Design a solution
		- Build a solution 
		- Test a solution
		- Deploy the solution to production 
		- Maintain the solution 
		- Retire the solution 
	+There is a classic method of conducting the early phases of this lifecycle that is called the Waterfall method. More modern approaches follow a paradigm called Agile. Scrum is an example of this technology. 
	 
-----------

Additional Resources:

*Software Development Process*
https://en.wikipedia.org/wiki/Software_development_process
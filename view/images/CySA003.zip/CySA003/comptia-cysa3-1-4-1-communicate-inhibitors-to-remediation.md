## Communicate Inhibitors to Remediation

At the end of this episode, I will be able to:    

1. Describe the issues that can inhibit vulnerability remediation.    

Learner Objective: *Describe the issues that can inhibit vulnerability remediation.*    

Description: In this episode, the learner will explore how to overcome the barriers or obstacles that inhibit a company's ability to remediate vulnerabilities in information systems through communication.

--------  

* Inhibitors to remediation
	+ Memorandum of understanding \(MOU\)
		- A statement of intent between the participating organizations to work together and often states goals, objectives, or the purpose for the partnership
		- Creation of these agreements should include security as well to avoid or include language for vulnerability remediation necessity
	+ Service-level agreement \(SLA\)
		- Defines the specific responsibilities of the service provider and sets the customer expectations.
		- Creation of these agreements should include a potential for service distruption if an incident happens.
	+ Organizational governance
		- Senior leadership may not be on board with interruptions
		- The overall process from detection to patching can be long and consume a lot of resources
		- Compensating controls may be required
		- While the remediation process may reduce service levels, it has to be conveyed that it will increase security and reduce risks to the company
	+ Degrading functionality
		- With SLAs in mind, reduced performance or functionality or service quality might put the company a risk of a violation, which can bring penalties.
		- Vulerability scanning can consume large amounts of bandwidth
		- Can interrupt business processes
	+ Legacy system
		- Legacy systems cannot be patched, present a high degree of risk
		- Virtually no support
		- May be required to support business systems as the cost may be to expensive to upgrade or deploy new software
		- May have to implement compensating controls
-----------

Additional Resources:

NIST - https://csrc.nist.gov/glossary/term/memorandum_of_understanding_or_agreement#:~:text=Definition(s)%3A,party%20to%20engage%20in%20action.

NIST - 
https://csrc.nist.gov/glossary/term/service_level_agreement

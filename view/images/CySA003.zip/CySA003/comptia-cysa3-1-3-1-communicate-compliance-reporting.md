## Communicate Compliance Reporting

At the end of this episode, I will be able to:    

1. Describe the importance of compliance reporting and communication.    

Learner Objective: *Describe the importance of compliance reporting and communication*    

Description: In this episode, the learner will explore the importance of communicating the results of compliance reports to the appropriate audiences.

--------  


* Compliance report is a form of documented evidence or proof detailing a company's adherence to a regulation, or standard or guideline.
* Communicating the importance to the industry in which an organization operates \(know the audience\). Commonly any company with information systems storing data.
* Technologies moves fast, regulations change
* Can determine whether an organization faces penalties
	+ Examples
		- ISO 27001 - requirements for establishing, implementing, maintaining and continually improving information security management systems
		- HIPPA - health care providers, health insurance companies
		- PCI-DSS - any company involved in payment card transactions
		- GDRP - any company that processes information on EU-based residents \(regardless of company location\)
		- SOC 2 - companies that store, process and maintain customer/client information \(Examples: Cloud and SaaS providers\)
* Examples:
	+ Provide secure communications to appropriate stake holders
	+ Examine and report on compliance requirements and scope
	+ Examine and report on controls providing adherence to requirements
	+ Compliance non-compliance \(or voliation\) awareness, and proposed controls
	+ Monitoring
	+ Validation of implemented controls
	
-----------

Additional Resources:
	+ If applicable
## CySA+ 003 - Domain 4.0 Outline

 High level topic overview

-------

* 4.1 - Explain the importance of vulnerability management reporting
and communication. 
	* Vulnerability management reporting \(1\)
		+ Vulnerabilities
		+ Affected hosts
		+ Risk score
		+ Mitigation
		+ Recurrence
		+ Prioritization
	* Compliance reports \(2\)
	* Action plans
		+ Configuration management
		+ Patching
	* Compensating controls
		+ Awareness, education, and training
		+ Changing business requirements
	* Inhibitors to remediation \(3\)
		+ Memorandum of understanding \(MOU\)
		+ Service-level agreement \(SLA\)
		+ Organizational governance
		+ Business process interruption
		+ Degrading functionality
		+ Legacy system
	 * Metrics and key performance indicators (KPIs) \(4)
		+ Trends
		+ Top 10
		+ Critical vulnerabilities and zero-days
		+ SLOs
	* Stakeholder identification and communication \(repeats in 4.2, cover once\)
* 4.2 - Explain the importance of incident response reporting and communication.
	* Communications \(1\)
		- IT security team - technical aspects of the incident
			- incident declaration
			- incident escalation
		- Executives - make key decisions \(CTO, CISO\)
		- Stakeholders - have an investment in the business
		- Legal - \(local, city, state and federal\)
		- Public relations
			* Customer communication
			* Media
		- Regulatory reporting - \(local, city, state and federal\)
		- Law enforcement - \(local, city, state and federal\)
	* Incident response reporting \(2\)
		+ Executive summary
		+ Who, what, when, where,and why
		+ Recommendations
		+ Timeline
		+ Impact
		+ Scope
		+ Evidence
	* Root cause analysis
	* Lessons learned
	* Metrics and KPIs \(3\)
		+ Mean time to detect
		+ Mean time to respond
		+ Mean time to remediate
		+ Alert volume
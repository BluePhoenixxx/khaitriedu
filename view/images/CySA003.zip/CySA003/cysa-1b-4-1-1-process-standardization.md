Filename: cysa-1b-4-1-1-process-standardization.md
Domain: Efficiency and Process Improvement in Security Operations
Episode: Process Standardization
=========================================================================

Process Standardization
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Identification of tasks suitable for automation
  - Repeatable/do not require human interaction
  - High Volume tasks
  - Digital Workflows
  - Error-Prone Tasks
  - Monotonous
  - Homogeneous data
+ Team coordination to manage and facilitate automation
  - Set Goals
  - Requirements
    + Regulatory Compliance
    + Secure Coding Practices
  - Communication and Notifications
    + Scheduled Meetings/Updates
    + Red Flag "Triggers"
    + Team Education
    + Best Practices

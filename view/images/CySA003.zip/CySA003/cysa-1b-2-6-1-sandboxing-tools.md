Filename: cysa-1b-2-6-1-sandboxing-tools.md
Domain: Tools and Techniques for Determining Malicious Activity
Episode: Sandboxing Tools
=========================================================================

Sandboxing Tools
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Joe Sandbox
  - https://joesandbox.com
+ Cuckoo Sandbox
  - https://cuckoosandbox.org

Filename: cysa-1b-1-1-1-malicious-network-activity.md
Domain: Analyze Indicators of Potentially Malicious Activity
Episode: Malicious Network Activity
=========================================================================

Malicious Network Activity
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Bandwidth consumption
+ Beaconing
+ Irregular peer-to-peer communication
+ Rogue devices on the network
+ Scans/sweeps
+ Unusual traffic spikes
+ Activity on unexpected ports

## Risk Management Principles
At the end of this episode, I will be able to:    

1. Explain the concepts of risk management in typical IT environments  

Learner Objective: *Explain risk management principles*    

Description: In this episode, you will learn all about key risk management principles. This includes a discussion of the various risk options common in organizations today. These include accept, transfer, avoid, and mitigate. 

--------  

* Risk Management Principles 
	+ Avoiding Risk - first you identify the risks, then you plan a course of action to avoid them
	+ Transferring Risk - often a special team outside of the organization 
	+ Mitigating Risk - stop the risk before it has the chance to make an impact 
	+ Accepting Risk - perhaps an option if the risk if very low or the target assets are not hugely important; you still need to plan for incident response 
	 
-----------

Additional Resources:

*Risk Response Planning*
https://www.managementstudyguide.com/risk-treatment.htm
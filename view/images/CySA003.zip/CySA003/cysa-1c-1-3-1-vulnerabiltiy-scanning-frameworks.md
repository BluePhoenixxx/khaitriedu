Filename: 1-3-1-vulnerability-scanning-frameworks.md
Domain: Implement Vulnerability Scanning Methods and Concepts
Episode Name: Vulnerability Scanning Frameworks
=========================================================================

Vulnerability Scanning Frameworks
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------


+ Payment Card Industry Data Security Standard (PCI DSS)
  - https://www.pcisecuritystandards.org/document_library/
  - https://docs-prv.pcisecuritystandards.org/PCI%20DSS/Standard/PCI-DSS-v4_0.pdf
+ Center for Internet Security (CIS) benchmarks
  - https://downloads.cisecurity.org/#/
+ Open Web Application Security Project (OWASP)
  - https://owasp.org/www-project-web-security-testing-guide/stable/
+ International Organization for Standardization (ISO) 27000 series
  - https://www.iso.org/isoiec-27001-information-security.html

Filename: 1-2-1-malicious-host-activity.md
Domain: Analyze Indicators of Potentially Malicious Activity
Episode: Malicious Host Activity
=========================================================================

Malicious Host Activity
-------------------------------------------------------------------------
Objectives
-------------------------------------------------------------------------

-------------------------------------------------------------------------



+ Processor consumption
+ Memory consumption
+ Drive capacity consumption
+ Unauthorized software
+ Malicious processes
+ Unauthorized changes
+ Unauthorized privileges
+ Data exfiltration
+ Abnormal OS process behavior
+ File system changes or anomalies
+ Registry changes or anomalies
+ Unauthorized scheduled tasks

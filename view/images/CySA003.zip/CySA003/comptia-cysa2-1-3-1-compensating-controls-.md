## Compensating Controls
At the end of this episode, I will be able to:    

1. Understand the concept of compensating controls and provide various examples of these control types. 

Learner Objective: *Explain the concept of compensating controls in cyber security and provide examples of these controls*    

Description: In this episode, you will learn about an important cyber security concept called compensating controls. You will also learn about the different types of compensating controls that exist in the industry. 

--------  

* Compensating Controls
	+ Compensating controls - seek to compensate for things that tech cannot solve
	+ Preventative controls - limit the possibility of an undesirable outcome
	+ Managerial controls - policies and procedures to achieve security goals 
	+ Corrective controls - correct undesirable outcomes to reduce risk
	+ Operational controls - security controls implemented by humans instead of systems 
	+ Technical controls - the use of tech (logic controls) to reduce vulnerabilities 
	+ Detective controls - controls seeking to identify risks and vulnerabilities 
	+ Responsive controls - a control designed to respond to a security event or flaw 
	 
-----------

Additional Resources:

*Security Controls and Security+*
https://blogs.getcertifiedgetahead.com/security-controls-and-security/
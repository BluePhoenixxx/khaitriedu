## Communicate Incident Response Metrics and KPIs

At the end of this episode, I will be able to:    

1. Identify the importance of incident response metrics and KPIs.    

Learner Objective: *Identify the importance of incident response metrics and KPIs.*    

Description: In this episode, the learner will identify common metrics and KPIs that need to be communicated as a part of incident response reporting. 

--------  

* Metrics and KPIs \(3\)
	+ Mean time to detect - a measurement of the average time from when an incident starts and the time taken to become aware of the vulerability.
	+ Mean time to identify - The
	+ Mean time to respond - a measurement of the average time taken for the initial response to a potential security incident.
	+ Mean time to contain - a measurement of time to quarantine a potential security incident
	+ Mean time to remediate - a measurement of the average time taken to close the vulnerability that triggered the incident response
	+ Mean time to recovery - a measurement of the average time it takes to restore operations to a pre-security incident state. 
	+ Alert volume - the amount of notifications indicating a potential security incident. The greater the amount of notifications can lead to "alert fatigue". It can be challenge to determine the critical alerts from low priority alerts. 

-----------

Additional Resources:
	+ If applicable